import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ContactComponent } from './Components/contact/contact.component';
import { ErrorComponent } from './Components/error/error.component';
import { HomeComponent } from './Components/home/home.component';
import { ProductComponent } from './Components/product/product.component';
import { ProductdetailsComponent } from './Components/productdetails/productdetails.component';


const routes: Routes = [
  
  {
    path :'home', component: HomeComponent
  },
  {
    path:'product' , component: ProductComponent,
  },
  { path: 'product/:id', component: ProductdetailsComponent},
  {
    path:'contact' , component: ContactComponent
  },
  {
    path:'error' , component: ErrorComponent
  },
  {
    path:'' , component: HomeComponent
  },
  {
    path:'**' ,
    redirectTo: 'error',
    pathMatch:'full'
  }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
