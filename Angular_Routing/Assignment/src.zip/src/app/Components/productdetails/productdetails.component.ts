import { Component, OnInit } from '@angular/core';
import {Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-productdetails',
  templateUrl: './productdetails.component.html',
  styleUrls: ['./productdetails.component.css']
})
export class ProductdetailsComponent implements OnInit {


  constructor(private _activatedroute : ActivatedRoute,
    private _router:Router,) { }

    id : any = 1;
    name = "Nokia 5.1 Plus";
    price = "8999";
    description = "Nokia 3GB/32GB"
    img = "../../assets/Nokia 5.1 Plus.jpg";

  ngOnInit(): void {
    this._activatedroute.paramMap.subscribe(params => { 
      this.id = params.get('id');
      
      for(let i=0; i<this.productdetails.length;i++)
      {
        if(this.id == this.productdetails[i].id)
        {
          this.name = this.productdetails[i].name;
          this.price = this.productdetails[i].price;
          this.description = this.productdetails[i].description;
          this.img = this.productdetails[i].img;
        }
      }
  });

  }

  
  productdetails = [
    {
      id : 1,
      name : "Nokia 5.1 Plus",
      price : "8999",
      description : "Nokia 3GB/32GB",
      img : "../../assets/Nokia 5.1 Plus.jpg"

    },
    {
      id : 2,
      name : "Samsung A10s",
      price : "10999",
      description : "Samsung 3GB/32GB",
      img : "../../assets/Samsung A10s.jpg"

    },
    {
      id : 3,
      name : "Redmi Mi note 5 pro",
      price : "12999",
      description : "Redmi 3GB/32GB",
      img : "../../assets/redmi.jpeg"

    },
    {
      id : 4,
      name : "Vivo Y2",
      price : "9500",
      description : "Vivo 3GB/32GB",
      img : "../../assets/vivo.jpeg"

    }
  ]

   

  onBack(): void {
    debugger
    this._router.navigate(['/product']);
 }

}
