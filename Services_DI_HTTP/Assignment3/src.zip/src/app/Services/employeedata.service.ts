import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Employee2 } from '../Model/employee2.model';

@Injectable({
  providedIn: 'root'
})
export class EmployeedataService {

  url = 'http://localhost:3000/data';
  constructor(private _http : HttpClient) { 
  }

  getEmployeeData():Observable<Employee2[]>
  {
    
    return this._http.get<Employee2[]>(this.url);
  }
}
