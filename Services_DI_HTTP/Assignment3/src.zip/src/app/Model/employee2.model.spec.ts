import { Employee2 } from './employee2.model';

describe('Employee2', () => {
  it('should create an instance', () => {
    expect(new Employee2()).toBeTruthy();
  });
});
