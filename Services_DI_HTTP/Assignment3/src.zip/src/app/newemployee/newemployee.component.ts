import { Component, OnInit } from '@angular/core';
import { EmployeedataService } from '../Services/employeedata.service';
import { Employee2 } from '../Model/employee2.model';

@Component({
  selector: 'app-newemployee',
  templateUrl: './newemployee.component.html',
  styleUrls: ['./newemployee.component.css']
})
export class NewemployeeComponent implements OnInit {

  constructor(private _edata : EmployeedataService) { }

  public empdata : Employee2[]=[];

  ngOnInit(): void {
    this._edata.getEmployeeData().subscribe(
      (data) =>{
        this.empdata = data;
        console.log(data);
        },
        (err)=>{
          console.log(err);
        })
  }

}
