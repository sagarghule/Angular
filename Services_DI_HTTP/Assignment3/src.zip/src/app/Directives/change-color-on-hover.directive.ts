import { Directive, ElementRef, HostListener } from '@angular/core';

@Directive({
  selector: '[appChangeColorOnHover]'
})
export class ChangeColorOnHoverDirective {

  constructor(private elRef: ElementRef) { 
  }
  @HostListener('mouseenter') onMouseEnter() {
    this.changeColor('#B2D732');
  }
  @HostListener('mouseleave') onMouseLeave() {
    this.changeColor('');
  }
  private changeColor(color: string) {
    this.elRef.nativeElement.style.backgroundColor = color;
  }  
}
