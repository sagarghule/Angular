import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {AuthGuardService} from './auth-guard.service';
import {CountryComponent} from './country/country.component';

const routes: Routes = [
  {
    path:'Country', 
    canActivate: [AuthGuardService],
    component:CountryComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
