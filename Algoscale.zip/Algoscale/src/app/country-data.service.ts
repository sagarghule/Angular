import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CountryDataService {

  constructor(private _http:HttpClient) { }

  baseUrl = "https://api.sampleapis.com/countries/countries";
  fetchCountry() {
    return this._http.get<any>(`${this.baseUrl}`);   
  }
}
