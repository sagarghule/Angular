import { Component, OnInit } from '@angular/core';
import { CountryDataService } from '../country-data.service';

@Component({
  selector: 'app-country',
  templateUrl: './country.component.html',
  styleUrls: ['./country.component.css']
})
export class CountryComponent implements OnInit {

  constructor(private _countryService : CountryDataService) { }

  ngOnInit(): void {
  }

  country : any[] = [];
  fetchCountry(){
    this._countryService.fetchCountry()
    .subscribe(
      res => {
        this.country.push(res);
      },
      err => {
        alert(err.error['error']);
      }
    )
  }

}
