export class Employee{
    constructor(
    public employeeID : any,
    public firstName : any,
    public lastName : any,
    public salary : any,
    public dob : any,
    public email : any,
    public action : any)
    {}
}