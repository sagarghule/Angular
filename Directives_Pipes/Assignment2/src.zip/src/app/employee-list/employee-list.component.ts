import { Component, OnInit } from '@angular/core';
import { Employee} from '../employee';
@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {

  emplist=[
    {
    "employeeID" : 1,
    "firstName" : "Sagar",
    "lastName" : "Ghule",
    "salary" : 30000,
    "dob" : "Wed May 21 1997 22:21:08 GMT+0530 (India Standard Time)",
    "email" : "sagar.ghule@gmail.com",
  },
  {
    "employeeID" : 2,
    "firstName" : "Sachinay",
    "lastName" : "Bhujbal",
    "salary" : 35000,
    "dob" : "Thu May 22 1997 22:21:08 GMT+0530 (India Standard Time)",
    "email" : "sachinay.bhujbal@gmail.com",
  },
  {
    "employeeID" : 3,
    "firstName" : "Shubham",
    "lastName" : "Deshmukh",
    "salary" : 32000,
    "dob" : "Fri May 23 1997 22:21:08 GMT+0530 (India Standard Time)",
    "email" : "shubham.deshmukh@gmail.com",
  },
  {
    "employeeID" : 4,
    "firstName" : "Akshay",
    "lastName" : "Kadlag",
    "salary" : 40000,
    "dob" : "Sat May 24 1997 22:21:08 GMT+0530 (India Standard Time)",
    "email" : "akshay.kadlag@gmail.com",
  },
  {
    "employeeID" : 5,
    "firstName" : "Pravin",
    "lastName" : "Kokane",
    "salary" : 30000,
    "dob" : "Sun May 25 1997 22:21:08 GMT+0530 (India Standard Time)",
    "email" : "pravin.kokane@gmail.com",
  }
]
 
 
  
  constructor() { }

  ngOnInit(): void {
  }

}
