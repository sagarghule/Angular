export class Details {

    constructor(
      public fname: string,
      public lname: string,
      public email: string,
      public date: string,
      public time: string,
      public impact: string,
      public description : string,

    ) {  }
  
  }