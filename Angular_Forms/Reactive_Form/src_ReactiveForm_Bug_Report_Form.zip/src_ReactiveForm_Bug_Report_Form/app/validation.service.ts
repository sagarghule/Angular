export class ValidationService 
{
    static getValidatorErrorMessage(validatorName: any, validatorValue?: any) 
    {
      let errorMessage : string = "";
      
      switch(validatorName)
      {
        case "required": errorMessage = "Required";
        break;
        case "invalidEmailAddress" : errorMessage = "Invalid email address";
        break;
        case "minlength" : errorMessage = `Minimum length ${validatorValue.requiredLength}`;
        break;
        default : errorMessage = "Required";
      }

      return errorMessage;
    }
  
    static emailValidator(control: { value: string; }) 
    {
      if (control.value.match(/[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/)) 
      {
        return null;
      } 
      else 
      {
        return { 'invalidEmailAddress': true };
      }
    }
}