import { Component, OnInit} from '@angular/core';
import {Validators, FormBuilder, AbstractControl, FormControl} from '@angular/forms';
import { Details} from '../details';
import { ValidationService } from '../validation.service';

@Component({
  selector: 'app-personal-info',
  templateUrl: './personal-info.component.html',
  styleUrls: ['./personal-info.component.css']
})
export class PersonalInfoComponent
{
  constructor(private _formBuilder : FormBuilder) { }
  impacts = ['Low','Medium','High'];
  submitted = false;

  bugReportForm = this._formBuilder.group({
    fname : ['',Validators.required],
    lname : ['',Validators.required],
    email : ['',[Validators.required, ValidationService.emailValidator]],
    date : ['',Validators.required],
    time : ['1',Validators.nullValidator],
    description : ['',[Validators.required, Validators.minLength(10)]],
    impact : ['Low',Validators.nullValidator]
  })

  detail = new Details('','','','','','','');
  onSubmit() 
  { 
    this.detail.fname = this.bugReportForm.value.fname;
    this.detail.lname = this.bugReportForm.value.lname;
    this.detail.email = this.bugReportForm.value.email;
    this.detail.date = this.bugReportForm.value.date;
    this.detail.time= this.bugReportForm.value.time;
    this.detail.impact = this.bugReportForm.value.impact;
    this.detail.description = this.bugReportForm.value.description;
    this.submitted = true; 
  }

}
