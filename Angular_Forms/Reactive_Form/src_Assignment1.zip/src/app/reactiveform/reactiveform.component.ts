import { Component } from '@angular/core';
import { Details} from '../details';

@Component({
  selector: 'app-reactiveform',
  templateUrl: './reactiveform.component.html',
  styleUrls: ['./reactiveform.component.css']
})
export class ReactiveformComponent {

  submitted = false;

  detail = new Details('','','','','');
  onSubmit() 
  { 
    this.submitted = true;
     
  }
  
  constructor() { }
}
