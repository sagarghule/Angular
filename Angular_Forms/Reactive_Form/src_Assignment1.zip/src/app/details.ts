export class Details {

    constructor(
      public fname:any,
      public email: any,
      public phonenum: any,
      public password: any,
      public cpassword : any,

    ) {  }
  
  }