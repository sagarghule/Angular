export class Details {

    constructor(
      public fname:any,
      public email: any,
      public address : any,
      public city : any,
      public phonenum: any,
      public password: any,
      public cpassword : any,

    ) {  }
  
  }