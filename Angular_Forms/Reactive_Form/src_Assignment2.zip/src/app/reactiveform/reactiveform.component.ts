import { Component } from '@angular/core';
import { Details} from '../details';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-reactiveform',
  templateUrl: './reactiveform.component.html',
  styleUrls: ['./reactiveform.component.css']
})
export class ReactiveformComponent {

  submitted = false;

  constructor(private _formBuilder: FormBuilder) 
  {

  }

  registerForm: FormGroup = this._formBuilder.group({});

  ngOnInit() {
    // initialising the form fields
    this.registerForm = this._formBuilder.group({
      fname: ['', Validators.required],
      address: ['', Validators.required],
      city: ['', Validators.required],
      phonenum: ['', Validators.required,Validators.minLength(10),Validators.maxLength(12)],
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]],
      cb : [false, Validators.requiredTrue],
      confirmPassword: ['', Validators.required],
    }, {
      validator: this.mustMatch('password', 'confirmPassword')
    });
  }

  mustMatch(pwd1: string, pwd2: string) {
    return (formGroup: FormGroup) => {
      const pwdControl = formGroup.controls[pwd1];
      const cnfPwdControl = formGroup.controls[pwd2];
      const existingErrors = cnfPwdControl.errors;
      // logic to match the values in both the fields
      if (pwdControl.value !== cnfPwdControl.value) {
        cnfPwdControl.setErrors({
          ...existingErrors,
          mustMatch: true
        })
      } else {
        cnfPwdControl.setErrors({
          ...existingErrors,
          mustMatch: false
        })
      }
    }
  }

  get f() {
    return this.registerForm.controls;
  }

  detail = new Details('','','','','','','');

  onSubmit() 
  { 
    this.submitted = true;
    if (this.registerForm.invalid) {
      return;
    }
  }
  
  
}
