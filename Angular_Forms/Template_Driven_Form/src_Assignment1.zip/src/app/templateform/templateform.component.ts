import { Component, OnInit } from '@angular/core';
import { Details} from '../details';

@Component({
  selector: 'app-templateform',
  templateUrl: './templateform.component.html',
  styleUrls: ['./templateform.component.css']
})
export class TemplateformComponent {

  submitted = false;

  detail = new Details('','','','','');
  onSubmit() 
  { 
    this.submitted = true; 
  }
  
  constructor() { }
}
