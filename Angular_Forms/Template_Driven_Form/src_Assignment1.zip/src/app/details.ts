export class Details {

    constructor(
      public fname: string,
      public email: string,
      public phonenum: string,
      public password: string,
      public cpassword : string,

    ) {  }
  
  }