import { Component, OnInit } from '@angular/core';
import {FormControl, FormGroup, Validators} from '@angular/forms';
import { Details} from '../details';

@Component({
  selector: 'app-personal-info',
  templateUrl: './personal-info.component.html',
  styleUrls: ['./personal-info.component.css']
})
export class PersonalInfoComponent
{
  constructor() { }
  impacts = ['Low','Medium','High'];
  submitted = false;

  detail = new Details('','','','','','','');
  onSubmit() 
  { 
    this.submitted = true; 
  }
}
