import {
    AbstractControl,
    ValidatorFn
} from '@angular/forms';

export function validateUserName(): ValidatorFn {
    // logic to validate the username
    // e.g. username must include string 'tcs'
    return (c: AbstractControl) => {
        const isValid = c.value?.toString().includes('tcs') ;
        if (isValid) {
            return null;
        } else {
            return {
                userName: {
                    valid: false
                }
            }
        }
    }
}