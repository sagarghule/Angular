import { FormGroup } from "@angular/forms";

export function MustMatch(controlName:string, matchingControlName:string)
{
    return (formGroup:FormGroup) =>{
    const control = formGroup.controls[controlName];
    const matchingControl = formGroup.controls[matchingControlName];

    if(!control || !matchingControl)
    {
        return null;        //return null if controls haven't initialised yet
    }

    if(matchingControl.errors && !matchingControl.errors.mustMatch)
    {
        return null;        //return null if there is another error ditected in matchingControl
    }

    if(control.value !== matchingControl.value)
    {
        matchingControl.setErrors({mustMatch:true});
        return null; 
    }
    else{
        matchingControl.setErrors(null);
        return null; 
    }
    }
    
}