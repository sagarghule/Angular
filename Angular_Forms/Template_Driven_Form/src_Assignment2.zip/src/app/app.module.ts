import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { UserNameValidator } from './directives/userName';
import { MustmatchDirective } from './directives/mustmatch.directive';

@NgModule({
  declarations: [
    AppComponent,
    UserNameValidator,
    MustmatchDirective
  ],
  imports: [
    BrowserModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
