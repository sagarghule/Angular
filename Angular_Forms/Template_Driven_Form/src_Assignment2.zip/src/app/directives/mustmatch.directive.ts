import { Directive,Input } from '@angular/core';
import { ValidationErrors, Validator, FormGroup, NG_VALIDATORS } from '@angular/forms';
import { MustMatch } from '../validators/passwordValidators';

@Directive({
  selector: '[appMustmatch][ngModel]',
  providers:[{provide:NG_VALIDATORS, useExisting:MustmatchDirective, multi:true}]
})
export class MustmatchDirective implements Validator{
  @Input('mustMatch') mustMatch : string[]=[];
  constructor() { }
  validate(formGroup:FormGroup):any{
    return MustMatch(this.mustMatch[0],this.mustMatch[1])(formGroup);
  }

}
