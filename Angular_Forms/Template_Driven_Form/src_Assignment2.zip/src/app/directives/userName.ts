import { Directive } from "@angular/core";
import { FormControl, NG_VALIDATORS, Validator, ValidatorFn } from "@angular/forms";


import { validateUserName } from "../validators/userNameValidators";

@Directive({
    selector: '[userName][ngModel]',
    providers: [
        {
            provide: NG_VALIDATORS,
            useExisting: UserNameValidator,
            multi: true
        }
    ]
})
export class UserNameValidator implements Validator {
    validator: ValidatorFn;

    constructor() {
        this.validator = validateUserName();
    }

    validate(c: FormControl) {
        return this.validator(c);
    }
}