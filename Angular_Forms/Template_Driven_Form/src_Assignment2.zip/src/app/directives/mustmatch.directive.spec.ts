import { MustmatchDirective } from './mustmatch.directive';

describe('MustmatchDirective', () => {
  it('should create an instance', () => {
    const directive = new MustmatchDirective();
    expect(directive).toBeTruthy();
  });
});
