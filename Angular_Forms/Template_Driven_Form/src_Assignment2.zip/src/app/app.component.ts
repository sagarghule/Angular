import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  formModel = {
    username: '',
    email: '',
    pnum: '',
    password: '',
    cpassword:''
  }

  submitted = false;

  formError = '';

  constructor() { }

  ngOnInit(): void {
  }

  submitMyData(myForm: NgForm) {
     debugger
    // const  { username, password } = myForm.form.value;
    // // can do a validation in the values, before we submit the values to the server
    // if (this.validateInput(myForm.form.value)){
    //   // make API calls and submit the data
    // } else {
    //   // in case of error, show the error to the user
    //   this.formError = 'Please provide valid values';
    // }
    
    this.formModel.username=myForm.form.value.username;
    this.formModel.email=myForm.form.value.email;
    this.formModel.pnum=myForm.form.value.pnum;
    this.formModel.password=myForm.form.value.password;
    this.formModel.cpassword=myForm.form.value.cpassword;

    this.submitted = true;
    
  }

  validateInput(formFields: any) {
    const  { username, password } = formFields;
    if (username.indexOf('@') < 0) {
      return false;
    }
    if (username.indexOf('.') < 0) {
      return false;
    }
    return true;
  }
}
