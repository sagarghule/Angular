import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ArithmeticService {

  constructor() { }

  add(num1:number, num2:number):string
  {
    return `Addition of ${num1} and ${num2} is ${num1 + num2}`;
  }

  sub(num1:number, num2:number):string
  {
    return `Subtraction of ${num1} and ${num2} is ${num1 - num2}`;
  }

  checkPrime(n:number): string 
  {
              
    var flag = true;
    var message = "";

    for(var i:number = 2; i <= n - 1; i++)
        if (n % i == 0) {
            flag = false;
            break;
        }
  
    if (flag == true)
        message = n + " is a prime number";
    else
        message = n + " is not a prime number";

    return message;
  }
  

}
