import { Component, OnInit } from '@angular/core';
import { StringService } from '../string.service';

@Component({
  selector: 'app-child2',
  templateUrl: './child2.component.html',
})
export class Child2Component implements OnInit {

  constructor(private _service2 : StringService) 
  { }

  public message : string = this._service2.countCapital("Sagar GHULE")
  ngOnInit(): void {
  }

}
