import { Component, OnInit } from '@angular/core';
import { ArithmeticService } from '../arithmetic.service';

@Component({
  selector: 'app-child1',
  templateUrl: './child1.component.html',
})
export class Child1Component implements OnInit {

  constructor(private _service1 : ArithmeticService) { }

  public message1 : string = this._service1.add(5,9);
  public message2 : string = this._service1.sub(15,5);
  public message3 : string = this._service1.checkPrime(11);


  ngOnInit(): void {
  }

}
