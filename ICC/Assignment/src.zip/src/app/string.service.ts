import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class StringService {

  constructor() { }

  countCapital(str:string):string
  {
    var upper = 0;

    for (var i = 0; i < str.length; i++)
    {
      if (str[i] >= "A" && str[i] <= "Z") upper++;
    }

    return `Number of Capital characters in "${str}" are ${upper}`;
  }
}
